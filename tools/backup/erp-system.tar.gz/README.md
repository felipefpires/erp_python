# Sistema ERP - Python

Sistema ERP completo desenvolvido em Python com Flask, contendo os seguintes módulos:

## Módulos Disponíveis

### 1. CRM (Customer Relationship Management)
- Gestão de clientes
- Histórico de vendas
- Análise de clientes
- Relatórios de vendas

### 2. Gestão de Estoque
- Controle de produtos
- Entrada e saída de mercadorias
- Alertas de estoque baixo
- Relatórios de inventário

### 3. Finanças
- Controle de receitas e despesas
- Fluxo de caixa
- Relatórios financeiros
- Gestão de contas a pagar e receber

### 4. Agendamentos
- Calendário de compromissos
- Gestão de reuniões
- Lembretes automáticos
- Integração com clientes

## Instalação

1. Clone o repositório
2. Instale as dependências:
```bash
pip install -r requirements.txt
```

3. Configure as variáveis de ambiente:
```bash
cp .env.example .env
```

4. Execute as migrações:
```bash
flask db init
flask db migrate
flask db upgrade
```

5. Execute o servidor:
```bash
python app.py
```

## Estrutura do Projeto

```
erp_project/
├── app/
│   ├── __init__.py
│   ├── models/
│   ├── routes/
│   ├── templates/
│   └── static/
├── migrations/
├── requirements.txt
├── app.py
└── README.md
```

## Tecnologias Utilizadas

- **Backend**: Flask, SQLAlchemy
- **Frontend**: HTML, CSS, JavaScript, Bootstrap
- **Banco de Dados**: SQLite (desenvolvimento) / PostgreSQL (produção)
- **Autenticação**: Flask-Login
- **Formulários**: WTForms


